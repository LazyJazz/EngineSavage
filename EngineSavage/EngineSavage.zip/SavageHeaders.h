#pragma once
#ifdef _WIN32
#include<graphics.h>
#include<Windows.h>
#endif
#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<ctime>
#include<queue>
#include<set>
#include<vector>
#include<cstdlib>
typedef unsigned int uint;
#define SAVAGE_FAILU (0xffffffffu)
#define SAVAGE_FAIL (-1)
using namespace std;