#pragma once
#include"SavageHeaders.h"

void SetLogMode(uint mode);

uint GetLogMode();

void SavageLog(const char* format, ...);