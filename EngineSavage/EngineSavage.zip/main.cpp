#include"Savage.h"

#ifdef _WIN32
int WINAPI WinMain(
	_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPSTR lpCmdLine,
	_In_ int nShowCmd
)
{
	AllocConsole();
	FILE* ihopethisvariablewontaffactothers;
	freopen_s(&ihopethisvariablewontaffactothers, "CON", "r", stdin);
	freopen_s(&ihopethisvariablewontaffactothers, "CON", "w", stdout);
	freopen_s(&ihopethisvariablewontaffactothers, "CON", "w", stderr);
#else
int main()
{
#endif
	Pos pos1,pos2;
	pos1 = Pos(2, 1, 3);
	pos2 = Pos(1, 2, 0);
	pos1.EliminateX().Print(); SavageLog("\n");
	pos1.EliminateY().Print(); SavageLog("\n");
	pos1.EliminateZ().Print(); SavageLog("\n");
	(pos1 + pos2).Print(); SavageLog("\n");
	(pos1 - pos2).Print(); SavageLog("\n");
	(pos1 * 3).Print(); SavageLog("\n");
	pos1.Print(); SavageLog("\n");
	SavageLog("pos1 Length:%d\n", pos1.Length());
	SavageLog("Hello,World!");
	while (true);
}
